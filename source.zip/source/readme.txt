=== AUO Music Player ===
Contributors: Anthony Udochukwu Onyekwere
Tags: theme, music, music player, songs
Requires at least: 3.5
Requires PHP: 5.6
Tested up to: 6.5
Stable version: 1.0.0

WP Child Theme Generator is an easy solution to all your child theme creating problems!

== Description ==

AUO Music Player is a plugin that enhances your WordPress website with great audio from your library. Upload your favourite songs and see how well your users enjoy each song by how many times a song is played.


Plugin : [Homepage](***)

== Installation ==

= Using The WordPress Dashboard =

1. Zip the contents of this folder
2. Navigate to the 'Add New' in the plugins dashboard
3. Click the Upload Plugin button
4. Click `Install Now`
5. Activate the plugin on the Plugin dashboard

On your front end pages, add the shortcode [auo_music_player]

== Changelog ==

= 1.0.0 =
Release Date: 13th August, 2024

* Fixed Authenticated (Administrator+) Arbitrary File Upload issue
* Minor fix - added condition to check for parent Screenshots

= 1.1.1 =
Release Date: 12th June, 2024

* Added a condition to check the file type of the file submitted by form

= 1.1.0 =
Release Date: 12th April, 2024

* Initial release